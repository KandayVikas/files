package org.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {

        int[] ar1=new int[]{-5, -2, 5, 2, 4, 7, 1, 8, 0, -8};

        int ar[]={1,2,3,4};
        int arr[]={2,9,8};
        List<Integer> l=new ArrayList<>();

        l=Arrays.stream(ar).boxed().collect(Collectors.toList());


//        int[] ar2=new int[ar1.length];
//        int pos=0;int neg=1;
//        for (int i=0;i< ar1.length;i++){
//
//            if(ar1[i]>0){
//                ar2[pos]=ar1[i];
//                pos=pos+2;
//            }
//            else{
//                ar2[neg]=ar1[i];
//                neg=neg+2;
//            }
//        }
        int n = ar1.length,
                pos = 0, neg = 1;
        int[] retarr = new int[n];

        for(int i=0; i<n; i++){
            if(ar1[i]>0){
                retarr[pos] = ar1[i];
                pos+=2;
            }else{
                retarr[neg] = ar1[i];
                neg+=2;
            }
        }


        System.out.println(Arrays.toString(retarr));

    }
}