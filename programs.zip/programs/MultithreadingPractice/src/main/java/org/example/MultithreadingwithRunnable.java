package org.example;

public class MultithreadingwithRunnable implements Runnable {


    @Override
    public void run() {
        int n = 3; // Number of threads
        for(int i=0;i<n;i++) {
            System.out.println("Thread " + Thread.currentThread().getId() + " is running");
        }
    }

    public static void main(String[] args) {
        MultithreadingwithRunnable multithreadingwithRunnable=new MultithreadingwithRunnable();
        Thread thread=new Thread(multithreadingwithRunnable);
        thread.start();

    }

}
