package org.example;

public class JoinExample extends Thread{

    @Override
    public void run() {
        for(int i=0;i<5;i++){
            System.out.println(Thread.currentThread().getName()+" "+i+" is running");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        JoinExample thread1=new JoinExample();
        thread1.setName("Thread1");
        thread1.start();
        thread1.join();

        System.out.println("I will wait until thread1 joins me");
        for(int i=0;i<5;i++){
            System.out.println("Main thread is running");
        }

    }
}
