package org.example;

public class BasicMultiThreading extends Thread{

    public void run(){
        try{

            //Displaying the thread
            //System.out.println("Thread "+Thread.currentThread().getId()+" is running");
            System.out.println(Thread.currentThread().getName()+" is running");
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }

    }
    public static void main(String[] args) {

          for (int i=0;i<6;i=i+2){
              BasicMultiThreading multiThread=new BasicMultiThreading();
              multiThread.setName("Thread "+i);
              multiThread.start();
          }

        for (int i=1;i<7;i=i+2){
            BasicMultiThreading multiThread=new BasicMultiThreading();
            multiThread.setName("Thread "+i);
            multiThread.start();
        }
    }
}
