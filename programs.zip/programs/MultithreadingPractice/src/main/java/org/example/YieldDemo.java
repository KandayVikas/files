package org.example;

import java.lang.*;

/*
Output:
Started Thread[First child thread,5,main]
Started Thread[Second child thread,5,main]
Ended Thread[First child thread,5,main]
Ended Thread[Second child thread,5,main]
Explanation:
•	Here, we create two threads, t1 and t2, that execute the run() method in YieldDemo Class.
•	As we can observe from the output, thread t1 start executing first. When the yield() method is invoked, thread t1 goes to the Ready state from the Running state, and thread t2 starts executing.
•	Then t2 goes in Ready state because yield() is called on it.
•	Now, thread t1 resumes its execution and terminates. The execution of the second thread follows this because it was in a Ready state.

*/

public class YieldDemo implements Runnable {
    public void run() {
        System.out.println("Started " + Thread.currentThread());
        // calling yield() method on current thread to move it
        // back to ready state from running state
        Thread.yield();
        System.out.println("Ended " + Thread.currentThread());
    }

    public static void main(String[] args) {
        YieldDemo y1 = new YieldDemo();
        // creating first thread
        Thread t1 = new Thread(y1, "First child thread");

        YieldDemo y2 = new YieldDemo();
        // creating second thread
        Thread t2 = new Thread(y1, "Second child thread");

        // calling thread will execute run() function
        t1.start();
        t2.start();
    }
}