package org.example;

import java.util.Scanner;

public class OddEvenwithThreads extends Thread{

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName()+" is running");
    }

    public static void main(String[] args) {
        System.out.println("Enter a number");
        Scanner scanner=new Scanner(System.in);

    }
}
