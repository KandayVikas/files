package com.vikas;

import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {


        HashSet<String> h=new HashSet<>();
        String word="hi hi hi helo hello helo";
        HashMap<String,Integer> map=new HashMap<>();

        for(String s:word.split(" ")){
            if(map.containsKey(s)){
                map.put(s,map.get(s)+1);
            }
            else {
                map.put(s,1);
            }
        }

       List<String> l=map.entrySet().stream().sorted(Comparator.comparing(Map.Entry::getValue)).map(Map.Entry::getKey).collect(Collectors.toList());

        System.out.println(l.get(l.size()-1));


    }

    private static void dupwords(String str) {

       HashSet<String> h=new HashSet<>();
       StringBuilder sb=new StringBuilder();
       String op="";
      for(String s:str.split(" ")){

          if(h.add(s)){
           op=op+s;
          }
      }

      //String st=h.stream().collect(Collectors.joining(" "));
        //System.out.println(st);
        System.out.println(op);
    }

    private static String getwordcount1(String str) {
        List<String> l=Arrays.asList(str.split(" "));
        Collections.reverse(l);

        return String.join(" ",l);

    }


    static void findPrimes(int a,int b){
        for(int i=a;i<=b;i++){

            boolean bo=isprime(i);
            if(bo) {
                System.out.println(i + " " + "isprime");
            }
            else {
                System.out.println("false");
            }
        }

    }

    private static boolean isprime(int n) {

        int flag=0;

        for(int i=2;i<=n/2;i++){
            if(n%i==0){
                flag=1;
            }
        }

        if(flag==1){
            return false;
        }
        else{
            return true;
        }
    }


    private static void array() {

        int arr[]=new int[7];
        System.out.println(arr[0]);
    }

    private static void palindrome() {
//        A prime number is a number that is divisible by only two numbers: 1 and itself.
//        So, if any number is divisible by any other number, it is not a prime number.
        Scanner scanner=new Scanner(System.in);
        String input= scanner.nextLine();
        //Method 1
      /*  StringBuffer sb=new StringBuffer(input);
        sb.reverse();
        if(input.equals(sb.toString())){
            System.out.println("palindrome");
        }
        else {
            System.out.println("no"+input+" "+sb);
        }
        //Method 2
        String op="";
        for(int i=input.length()-1;i>=0;i--){
            op=op+input.charAt(i);
        }
        if(input.equals(op)){
            System.out.println("palindrome");
        }*/
        //Method 3 by recursion
        if(ispalindrome(input))
            System.out.println("palindrome");
        else
            System.out.println("no");
    }

    private static boolean ispalindrome(String input) {
        if (input.length() == 0 || input.length() == 1)
            return true;
        if (input.charAt(0) == input.charAt(input.length() - 1)) {
            System.out.println(input.substring(1, input.length() - 1));
            return ispalindrome(input.substring(1, input.length() - 1));
        }
        return false;
    }
}