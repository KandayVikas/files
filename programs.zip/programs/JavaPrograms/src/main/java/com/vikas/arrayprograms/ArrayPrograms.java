package com.vikas.arrayprograms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.stream.Collectors;

public class ArrayPrograms {

    public static void main(String[] args) {
       // arrayContainsNumber();
        //alternateNums();
        //contiguoussubarraySum();
        //intersectionUnionofArrays();
        sortZerosandOnes();
    }

    private static void sortZerosandOnes() {
        int ar[] = {0,1,0,1,0,1,0,1};
       // Arrays.sort(ar);
        int a=0,b=1;
        for(int i=0;i<ar.length-1;i++){
           if(Math.min(ar[i],ar[i+1]) == ar[i+1]){
               int temp = ar[i];
               ar[i] = ar[i+1];
               ar[i+1] =temp;
           }
        }
        System.out.println(Arrays.toString(ar));

    }

    private static void intersectionUnionofArrays() {
        int ar1[]={1,2,3,4,5};
        int ar2[]={2,22,33,4,6};
        ArrayList<Integer> l1=new ArrayList<>();
        l1.addAll(Arrays.asList(Arrays.stream(ar1).boxed().toArray(Integer[]::new)));
        //l1.addAll(Arrays.asList(Arrays.stream(ar2).boxed().toArray(Integer[]::new)));
        //System.out.println(l1.stream().distinct().collect(Collectors.toList()));
       //l1.stream().filter(s->s)

        System.out.println(l1);
        HashSet<Integer> h=new HashSet<>();
        h.addAll(Arrays.asList(Arrays.stream(ar1).boxed().toArray(Integer[]::new)));
        h.addAll(Arrays.asList(Arrays.stream(ar2).boxed().toArray(Integer[]::new)));
        //System.out.println(h);

    }

    private static void contiguoussubarraySum() {
        int ar[]={1,2,3,1,2,3};
        int result=6;
        for(int i=0;i<ar.length;i++){
            int sum=0;
            for(int j=i;j<ar.length;j++){
              sum=sum+ar[j];
              if(sum==result){
                  printSubArray(ar,i,j);
              }
            }
        }
    }

    private static void printSubArray(int ar[],int i, int j) {
        for(int k=i;k<j+1;k++){
            System.out.print(ar[k]+" ");
        }
        System.out.println();

    }

    private static void alternateNums() {
        int[] ar1=new int[]{-5, -2, 5, 2, 4, 7, 1, 8, 0, -8};
        int[] ar2=new int[ar1.length];
        int a=0,b=0;
        for (int i=0;i< ar1.length;i++){

            if(ar1[i]>0){
                ar2[b]=ar1[i];
                b=b+2;
            }
            else{
                b++;
                ar2[b]=ar1[i];
                b=b+2;
            }
        }
        System.out.println(Arrays.toString(ar2));
    }


    private static void arrayContainsNumber() {

        Integer[] ar=new Integer[]{1,2,2,3,4,5};
        int[] ar1=new int[]{1,2,3,};
        //int[] -> Integer[]
        //finding a number in array
        System.out.println(Arrays.stream(ar1).boxed().collect(Collectors.toList()).contains(2));
        //optional class so use get
        System.out.println(Arrays.stream(ar).min(Integer::compare).get());


    }
}
