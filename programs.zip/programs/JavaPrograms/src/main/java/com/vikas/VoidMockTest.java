package com.vikas;

public class VoidMockTest {

    public void doAction(String name){
        System.out.println("Hello "+name);
    }
    public static void main(String[] args) {
        VoidMockTest voidMockTest=new VoidMockTest();
          voidMockTest.doAction("World");
        System.out.println("Its completed!!");
    }
}
