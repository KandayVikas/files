package com.vikas.stringprograms;

// Java program to generate largest
// possible number with given digits
import java.util.Arrays;

class LargestCombinationNum {
    // Function to generate largest
    // possible number with given digits
    static String findMaxNum(String arr[], int n)
    {

        Arrays.sort(arr,(a,b)->(b+a).compareTo(a+b));

        return String.join("",arr);


    }

    // Driver code
    public static void main(String[] args)
    {
        String arr[] = { "3","5","9","30", "34"};

        int n = arr.length;

        System.out.println(findMaxNum(arr, n));
    }
}


