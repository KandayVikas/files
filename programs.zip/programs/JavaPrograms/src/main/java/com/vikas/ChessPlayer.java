package com.vikas;

public class ChessPlayer {

    private String name;
    private String category;
    private Integer age;

    private Integer wins;
    private Integer points;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Integer getWins() {
        return wins;
    }

    public void setWins(Integer wins) {
        this.wins = wins;
    }

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }

    public void assignCategory() throws Exception {
        System.out.println("assigning category "+this.name);
        if(this.getAge()<5){
            throw new Exception("Player age is too less");
        }

        this.category=this.getAge()<18 ? "under 18" :"senior";
    }

    public ChessPlayer(String name, Integer age) {
        this.name = name;
        this.age = age;
    }
}
