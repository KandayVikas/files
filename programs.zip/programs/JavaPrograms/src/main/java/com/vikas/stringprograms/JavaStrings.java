package com.vikas.stringprograms;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class JavaStrings {

    public static void main(String[] args) {
//        getwordcount();
//        getreversedsentence();
//        getmaxOcc();
//        findDuplicateandDistictCharsinString();
//        findDuplicateandDistictWordsinString();
//        checkanagaram();
//        deletechars();
        System.out.println(findwhetherstringisuniqueornot("helo"));
        getvowelsandconsonantsbyregex();
        findtwonumberswhosesumisresult();
//        System.out.println(isIsomorphic("aaab","xxxy"));
        regexexample();
    }

    private static void findtwonumberswhosesumisresult() {
        int ar[] = {8,3,1,2,6,7};
        int req=10, c=0;
        HashMap<Integer,Integer> hashMap=new HashMap<Integer,Integer>();
        HashMap<Integer,Integer> result=new HashMap<Integer,Integer>();
        for(int i=0;i<ar.length;i++) {

            c=req-ar[i];

            if(c>0 && hashMap.containsKey(c)) {
                // System.out.println(ar[i]+"--"+c);
                result.put(ar[i],c);
            }
            else {
                hashMap.put(ar[i], i);
            }
        }

        result.entrySet().stream().forEach(s->System.out.println(s.getKey()+"---"+s.getValue()));//forEach(s->s.getKey()+"--"+s.getValue());

    }

    private static void getvowelsandconsonantsbyregex() {

//        String s="aeiouzfg";
//
//        String p1="[^aeiou]+";
//
//        for(int i=0;i<s.length();i++){
//            if((s.charAt(i)+"").matches(p1)){


        String s="vghaehikou";
        String s1="";
        String s2="";
        Pattern p=Pattern.compile("[^aeiou]+");
        for (int i = 0; i < s.length(); i++) {
            String charAtI = s.charAt(i) + "";
            if(p.matcher(charAtI).matches()) {
                s1=s1+charAtI;
            }
            else
                s2=s2+charAtI;
        }
        System.out.print("consonants "+s1+'\n'+"vowles "+s2);
        //Method 2
        //String s="vghaehikou";
        //Pattern p=Pattern.compile("[^aeiou]+");
//		Matcher m=p.matcher(s);//("[^aeiou]+", s);
//		while(m.find()) {
//			s1=s1+m.group();
//		}
//
//		System.out.println(s1+"----"+s2);
//		System.out.println("vowelsss "+s.replaceAll("[^aeiou]+", ""));

    }

    private static boolean findwhetherstringisuniqueornot(String str) {

        boolean containsUnique = false;

        for(char c : str.toCharArray()){
            if(str.indexOf(c) == str.lastIndexOf(c)){
                containsUnique = true;
            } else {
                containsUnique = false;
                break;
            }
        }
        return containsUnique;

    }

    private static void regexexample() {
//        String s="inpu1ts yy2y";
//        StringBuffer sb=new StringBuffer();
        ArrayList<String> l=new ArrayList<String>();
//        Pattern pattern = Pattern.compile("w3schools");
        Pattern p=Pattern.compile("[^A-Za-z0-9 ]+");
        Matcher matcher = p.matcher("Visi2t W3Scho1ol4s!");

        while(matcher.find()){
            l.add(matcher.group());
        }
        //System.out.println("sbregex "+);

        System.out.println(String.join("",l));
       // System.out.println("sbregex111 "+l.stream().map(String::valueOf).collect(Collectors.joining()));
        //System.out.println("sbregex33 "+l.stream().collect(Collectors.joining()));
    }

    private static void deletechars() {
        String str = "Hello, World_123!!,_!";
        String charsToRemove = ",_!";
        for(String s:charsToRemove.split("")){
                str=str.replaceAll(s,"");
        }
        System.out.println(str);
    }

    public static boolean isIsomorphic(String str1, String str2) {
        //map.put will return previous value if present or returns null if it is new value
        Map<Character, Integer> map1 = new HashMap<>();
        Map<Character, Integer> map2 = new HashMap<>();
        for(int i = 0; i < str1.length(); i++) {
            Integer s1Prv=map1.put(str1.charAt(i), i);
            Integer s2Prv=map2.put(str2.charAt(i), i);

            System.out.println("s1 "+s1Prv);
            System.out.println("s2 "+s2Prv);
            if(s1Prv != s2Prv) {
                return false;
            }
        }
        return true;
    }

    private static void getmaxOcc() {

        String maxoc = "gghhhkkkkkkfllll";

        HashMap<String, Integer> hashMap = new HashMap<>();
        for (String op : maxoc.split("")) {
            if (hashMap.containsKey(op)) {
                hashMap.put(op, hashMap.get(op) + 1);
            } else {
                hashMap.put(op, 1);
            }
        }

        System.out.println(hashMap.entrySet().stream().sorted(Comparator.comparing(Map.Entry::getValue)).map(Map.Entry::getKey).collect(Collectors.toList()).get(hashMap.size() - 1));
        System.out.println(hashMap);
        //Method 2
        System.out.println(Arrays.stream(maxoc.split("")).collect(Collectors.groupingBy(j->j,Collectors.counting())).entrySet().stream()
                .sorted(Comparator.comparing(Map.Entry::getValue)).map(Map.Entry::getKey).reduce((first, second) -> second).orElse("no last element"));
    }
    private static void checkanagaram() {


        //anagram means both string are not equal but there characters order will be different
        String s = "mary";
        String s1 = "army";
        int flag = 0;
        char[] ar1 = s.toLowerCase().toCharArray();
        char ar2[] = s1.toLowerCase().toCharArray();

        Arrays.sort(ar1);
        Arrays.sort(ar2);
//Method 2
//        s=Arrays.stream(s1.toLowerCase().split("")).sorted().collect(Collectors.joining());
//        s1=Arrays.stream(s2.toLowerCase().split("")).sorted().collect(Collectors.joining());
        if (Arrays.equals(ar1, ar2))
            System.out.println("anagram");
        else
            System.out.println("not anagram");
    }
    private static void getreversedsentence() {
        String s="Hi, hello world! Good morning.....";
        StringBuffer sb=new StringBuffer(s);
        sb.reverse();
        System.out.println(sb);

        //or
        List<String> l= Arrays.asList(s.split(" "));//Arrays.stream(s.split(" ")).collect(Collectors.toList());
        Collections.reverse(l);
        System.out.println(String.join(" ",l));

    }

    private static void getwordcount() {
        String s="hi helo gm";
        System.out.println(s.split(" ").length);
    }

    private static void findDuplicateandDistictCharsinString() {

        String g="hello";
       // Map<Object, Long> m1=
        Arrays.stream(g.split("")).collect(Collectors.groupingBy(s->s,Collectors.counting()))
                .entrySet().stream().filter(m->m.getValue()==1).forEach(s->System.out.print(s.getKey()+" "));

        //method 2

        String s="hello";
        HashSet<String> items=new HashSet<>();

        Arrays.stream(s.split("")).filter(n -> !items.add(n)).collect(Collectors.toSet()).forEach(System.out::print);
        Arrays.stream(s.split("")).distinct().forEach(System.out::print);

    }

    private static void findDuplicateandDistictWordsinString() {

        String ar[]=new String[]{"hello","hi","hello","Hi"};
       // Map<Object,Long> m=Arrays.stream(ar).collect(Collectors.groupingBy(s->s.toLowerCase(),Collectors.counting()));

        Arrays.stream(ar).collect(Collectors.groupingBy(s->s.toLowerCase(),Collectors.counting())).
                entrySet().stream().filter(mm->mm.getValue()==1).forEach(s->System.out.print(s.getKey()+" "));;

        //method 2
        String s="hello hello hi";
        HashSet<String> items=new HashSet<>();

        Arrays.stream(s.split(" ")).filter(n -> !items.add(n)).collect(Collectors.toSet()).forEach(System.out::print);
        Arrays.stream(s.split(" ")).distinct().forEach(System.out::print);

        //duplicates in array //use boxed to convert int to Integer
        int ar1[]={2,3,4,5,5,1,7,7,7};
        HashSet<Integer> h=new HashSet<>();
        Arrays.stream(ar1).boxed().filter(a->!h.add(a)).collect(Collectors.toSet()).forEach(System.out::println);

    }
}
