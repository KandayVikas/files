import com.vikas.ChessPlayer;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class ChessPlayerTest {

//    What is the difference between mock and spy mock?
//    Mocks are used to create fully mock or dummy objects. It is mainly used in large test suites.
//    Spies are used for creating partial or half mock objects. Like mock, spies are also used in large test suites

//    Spy objects are useful when you want to test the real implementation of an object but also need to stub or mock specific methods.
    @Test
    public void testAssignCategory() throws Exception {
        //by using spy partial mock can happen
        ChessPlayer chessPlayer=new ChessPlayer("John",35);
        ChessPlayer chessPlayerSpy= Mockito.spy(chessPlayer);
       // Mockito.doNothing().when(chessPlayerSpy).assignCategory();
        chessPlayerSpy.assignCategory();
        assertEquals("senior",chessPlayerSpy.getCategory());


    }

    //3 30 34 5 9 934
    // 9 5 3 34 30

    //3 5 9 30 34

    //300
    // 9534330

    @Test
    public void testAssignCategoryMock() throws Exception {

      //  ChessPlayer chessPlayer=new ChessPlayer("John",35);
        ChessPlayer chessPlayerMock= Mockito.mock(ChessPlayer.class);

        when(chessPlayerMock.getAge()).thenReturn(38);
        doCallRealMethod().when(chessPlayerMock).assignCategory();
        doCallRealMethod().when(chessPlayerMock).getCategory();
        chessPlayerMock.assignCategory();
        //assertEquals(null,chessPlayerMock.getCategory());
        assertEquals("senior",chessPlayerMock.getCategory());

    }

    @Test//(expected= Exception.class)
    public void testAssignCategoryMockException() throws Exception {

        //  ChessPlayer chessPlayer=new ChessPlayer("John",35);
        ChessPlayer chessPlayerMock= Mockito.mock(ChessPlayer.class);

       doThrow(Exception.class).when(chessPlayerMock).assignCategory();
       chessPlayerMock.assignCategory();

    }
}
