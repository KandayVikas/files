import com.vikas.VoidMockTest;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class VoidMockTesting {

    @Test
    public void testVoid(){

        VoidMockTest voidMockTest = spy(new VoidMockTest());

        //doNothing()
        //Mockito.doNothing().when(voidMockTest).doAction(any());

//        To make a void method throw an exception, we use doThrow().
//        The exception we pass to the doThrow() is thrown when the mocked method is called.
        //doThrow()
        //Mockito.doThrow(IndexOutOfBoundsException.class).when(voidMockTest).doAction(any());

        //SomeClass mockInstance = mock(SomeClass.class);
        voidMockTest.doAction("World!");

        //voidMockTest.doAction("World!");

//        With Mockito, we use verify() to check if a method has been called.
//        The example below shows two ways of implementing this.
//            times(1) is the default value, so you can omit it to have more readable code.

        // using the default
        //Mockito.verify(voidMockTest).doAction(anyString());
       // explicitly stating how many times a method is called
        Mockito.verify(voidMockTest, times(2)).doAction(anyString());




        //----------------------------------------------------------------------------------










    }
}