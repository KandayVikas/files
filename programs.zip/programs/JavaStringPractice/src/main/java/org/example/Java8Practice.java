package org.example;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.LongStream;

public class Java8Practice {
    private static List<Integer> getCollect(List<Integer> list, Function<Integer, Integer> integerFunction) {
        return list.stream().map(integerFunction).collect(Collectors.toList());
    }

    public static Predicate<String> checkStartsWith(String a){
        return s->s.startsWith(a);
    }

    public static void main(String[] args) {

        //Functional Interface
        List<Integer> l= Arrays.asList(1,2,3,4,4,6);

        List<Integer> list2= getCollect(l, x -> x * x * x);
        System.out.println("list2 "+list2);

        System.out.println(l.stream().reduce(0, binaryoperator));
        l.stream().map(unaryOperator).forEach(System.out::print);

        //l.stream().filter(s->s>2).forEach(System.out::print);

        l.stream().filter(predicate).map(function).forEach(consumer);

        Arrays.stream(supplier.get()).forEach(System.out::print);

        //higherorderfunctions In below example filter is a higher order function which take function as input and return function
        List<String> ll= Arrays.asList("agent","akhil","kane mama");

        ll.stream().filter(checkStartsWith("a")).forEach(System.out::print);

        System.out.println(IntStream.iterate(1,e->e+2).limit(3).peek(System.out::print).sum());

        //But for Factorial of 50 it will exceed Long max value so we can use BigInteger
        System.out.println(LongStream.rangeClosed(1,50).mapToObj(BigInteger::valueOf).reduce(BigInteger.ONE,BigInteger::multiply));

       List<Integer> l4=Arrays.asList(1,2,3,4);
        List<Integer> l5=Arrays.asList(5,6,7);
        List<Integer> l6=Arrays.asList(8,9,10);

        List<List<Integer>> l7=Arrays.asList(l4,l5,l6);
        l7.stream().collect(Collectors.toList()).forEach(System.out::print);
        l7.stream().flatMap(list->list.stream()).collect(Collectors.toList()).forEach(System.out::print);

        String[] st=new String[5];


            System.out.println(st[4].toLowerCase());

        Optional<String> op= Optional.ofNullable(st[4]);
        if(op.isPresent()){
            System.out.println(st[4].toLowerCase());
        }
        else
            System.out.println("word is null");




    }
    public static Predicate<Integer> predicate=new Predicate<Integer>() {
        @Override
        public boolean test(Integer integer) {
           return integer>2;
        }
    };

    //public static Predicate<Integer> predicate1= (integer) -> {return integer>2; };

    public static Function<Integer,Integer> function=new Function<Integer,Integer>() {
        @Override
        public Integer apply(Integer o) {
            return o*o;
        }
    };

    public static Consumer<Integer> consumer=new Consumer<Integer>() {
        @Override
        public void accept(Integer integer) {
            System.out.print(integer+" ");
        }
    };

    public static Supplier<Integer[]> supplier=new Supplier<Integer[]>() {
        @Override
        public Integer[] get() {
            return new Integer[]{1,2,3};
        }
    };

    public static BinaryOperator<Integer> binaryoperator=new BinaryOperator<Integer>() {
        @Override
        public Integer apply(Integer integer, Integer integer2) {
            return integer+integer2;
        }
    };


    public static UnaryOperator<Integer> unaryOperator=new UnaryOperator<Integer>() {
        @Override
        public Integer apply(Integer integer) {
            return integer*3;
        }
    };

}
