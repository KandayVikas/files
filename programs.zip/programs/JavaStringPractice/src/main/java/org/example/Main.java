package org.example;

import java.sql.SQLOutput;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.maxBy;
import static java.util.stream.Collectors.toMap;

public class Main {



    public static void main(String[] args) {
     String s= "hi hello how how how hellooo hellooo";
//        List<String> l= Arrays.stream(s.split(" ")).collect(Collectors.toList());
//       // System.out.println(s.split(" ").length);
//        Collections.reverse(l);
//        System.out.println(String.join(" ",l));
        HashMap<String,Integer> map=new HashMap<>();
        HashSet<String> set=new HashSet<>();

       for(String element:s.split(" ")){
           if(map.containsKey(element)){
               map.put(element,map.get(element)+1);
           }
           else {
               map.put(element,1);
           }
       }

        //System.out.println(map.entrySet().stream().max(Comparator.comparing(Map.Entry::getValue)).map(Map.Entry::getKey).get());

        Arrays.stream(s.split(" ")).filter(element->set.add(element)).forEach(System.out::println);
     //   System.out.println(Arrays.toString(ar2));
        StringBuffer sb=new StringBuffer("gggghhhhert");
        sb.delete(0,1);
        System.out.println(sb);

        int ar[] = {8,3,1,2,6,7};
       // System.out.println(isIsomorphicc("aaab","xxxy"));

//        int ar[]={2,3,4,5,5,1,7,7,7};
//       HashSet<Integer> h=new HashSet<>();
//         Arrays.stream(ar).reduce(0, Integer::sum);
//        Arrays.stream(ar).boxed().filter(a->!h.add(a)).collect(Collectors.toSet()).forEach(System.out::println);


//        for(Integer i:ar){
//            if(!h.add(i)){
//                h.add(i);
//            }
//        }

       // System.out.println(h);
    }

//    private static boolean isIsomorphicc(String aaab, String xxxy) {
//
//        HashMap<String,Integer> h=new HashMap<>();
//
//        for(String s:aaab.split("")){
//            h.put(s,1);
//        }
//    }

    private static int[] getSecondOrderElements(int[] ar) {

        int[] arr= new int[2];
        String[] arr1=new String[2];
        arr1[0]="hi hell";
        arr1[1]="hi hel hello";
        System.out.println(Arrays.stream(arr1).collect(Collectors.groupingBy(String::length)));
        int min= Integer.MAX_VALUE;
        int max= Integer.MIN_VALUE;
        int sec_min= Integer.MAX_VALUE;
        int sec_max= Integer.MIN_VALUE;
        //1 2 3
        for(int i=0;i<ar.length;i++){
            min = Integer.min(max,ar[i]);
            max = Integer.max(min,ar[i]);
        }
        for(int i=0;i<ar.length;i++){

            if (ar[i] < sec_min && ar[i] != min)
            {
                sec_min = ar[i];
            }
            if (ar[i] > sec_max && ar[i] != max)
            {
                sec_max = ar[i];
            }
        }

      arr[0]=sec_min;
        arr[1]=sec_max;
return arr;
    }


}